﻿using System;
namespace Projekti201801Esimerkit
{
    public class Tuote
    {

        public string Tuotenimi { get; set; }
        public int Tuotenumero { get; set; }
        public double Hinta { get; set; }
        public double Alv { get; set; }

        public Tuote()
        {
        }

    }
}
