﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using Verkkokauppa.Core;

namespace Projekti201801Tests
{
    /* TARINA:
     * 
     * Yritysasiakkaana (jäljempänä asiakas) tahdon pystyä poimimaan tilaukseen 
     * haluamani tuotteita, jotta voin luoda haluamani tilauksen.
     * 
     * TAPAUS 01
     * 
     * TAVOITE
     * Verkkokauppaohjelmistoa käyttävä asiakas saa lisättyä vahvistamattomaan 
     * tilaukseen tuotteita.
     * 
     * ESIEHDOT
     * Ohjelmassa on oltava saatavilla olevia tuotteita, joita asiakas voi valita.
     * 
     * ONNISTUNUT LOPPUTULOS
     * Asiakas näkee tilauksessaan tuotteen, jonka hän on toiminnon aikana valinnut.
     * 
     * VIRHEELLINEN LOPPUTULOS
     * Asiakkaan valitsema tuote ei näytä tilauksessa. Ohjelma ei kaadu mikäli 
     * virhe sattuu vaan ilmoittaa virheellisestä toimenpiteestä.
     * 
     * KUVAUS KÄYTTÖTAPAUKSESTA
     * 1. Asiakas saa listan valittavista tuotteista.
     * 2. Asiakas valitsee tuotteen listalta ja hyväksyy sen tilaukseen.
     * 3. (järjestelmä lisää tässä kohdin tuotteen tilaukseen)
     * 4. (järjestelmä ilmoittaa asiakkaalle, että tuote on lisätty tilaukseen)
     * 
     * KUVAUS VIRHEELLISESTÄ KÄYTTÖTAPAUKSESTA
     * 
     * Kohdassa 3 tuotteen lisäys tilaukseen ei onnistu. Kohdan 4 sijaan 
     * ohjelman tulisi ilmoittaa asiakkaalle, että tuotetta ei voitu lisätä tilaukseen.
     * 
     */

    [TestFixture()]
    public class TilausTest
    {

        Tilaus tilaus;

        [SetUp()]
        public void SetUp() {
            this.tilaus = new Tilaus();
        }

        [Test()]
        public void TilaukseenVoidaanLisataTuote()
        {
            Tuote tuote = LuoTestiTuote(101, "Automaali, punainen");
            tilaus.LisaaTuote(tuote);

            List<Tuote> tilauksenTuotteet = tilaus.Tuotteet;

            Assert.IsNotNull(tilauksenTuotteet);
            Assert.AreEqual(1, tilauksenTuotteet.Count());
        }

        [Test()]
        public void TilaukseenEiVoidaLisataTyhjaaTuotetta()
        {
            Tuote tuote = null;
            tilaus.LisaaTuote(tuote);

            List<Tuote> tilauksenTuotteet = tilaus.Tuotteet;

            Assert.IsNotNull(tilauksenTuotteet);
            Assert.AreEqual(0, tilauksenTuotteet.Count());
        }

        [Test()]
        public void TilaukseenVoidaanLisataUseitaTuotteita()
        {
            Tuote tuote01 = LuoTestiTuote(101, "Automaali, punainen");
            Tuote tuote02 = LuoTestiTuote(102, "Automaali, sininen");
            tilaus.LisaaTuote(tuote01);
            tilaus.LisaaTuote(tuote02);

            List<Tuote> tilauksenTuotteet = tilaus.Tuotteet;

            Assert.AreEqual(2, tilauksenTuotteet.Count());
        }

        [Test()]
        public void LaskeTilauksenKokonaishinta() {
            Tuote tuote = LuoTestiTuote(101, "Automaali, punainen");
            tilaus.LisaaTuote(tuote);

            double kokonaishinta = this.tilaus.LaskeKokonaishinta();

            Assert.AreEqual(35.0, kokonaishinta);
        }

        [Test()]
        public void LaskeTilauksenKokonaishintaKahdellaTuotteella()
        {
            Tuote tuote01 = LuoTestiTuote(101, "Automaali, punainen");
            Tuote tuote02 = LuoTestiTuote(102, "Automaali, sininen");
            tilaus.LisaaTuote(tuote01);
            tilaus.LisaaTuote(tuote02);

            double kokonaishinta = this.tilaus.LaskeKokonaishinta();

            Assert.AreEqual(70.0, kokonaishinta);
        }

        private Tuote LuoTestiTuote(int tuotenumero, string tuotenimi)
        {
            return new Tuote()
            {
                Tuotenimi = tuotenimi,
                Tuotenumero = tuotenumero,
                Alv = 0.24,
                Hinta = 35.0
            };
        }
    }
}
