﻿using System;
using System.Collections.Generic;
using System.Linq;
using Verkkokauppa.Core;

namespace Projekti201801Esimerkit
{
    // Ohjelman pääluokka, ns. pääohjelma, josta kaikki toiminnallisuus
    // alkaa.

    class MainClass
    {

        // Main metodia kutsutaan kun ohjelma käynnistyy. Tämä on ensimmäinen
        // metodi mitä siis ohjelma kutsuu ja josta kaikki alkaa.
        // 
        // "string[] args" tarkoittaa parametreja, jos niitä on annettu ohjelman
        // alkaessa esimerkiksi komentokehotteesta.

        public static void Main(string[] args)
        {
            // Varsinaisen ohjelman suoritus alkaa.
            Tulostaja tulostaja = new Tulostaja();
            Lukija lukija = new Lukija();
            CsvTiedosto csv = new CsvTiedosto();


            const string tallennusSijainti = @"/Users/sovelluskontti/dev/tmp/";
            const string tiedostopolkuTuotelista = tallennusSijainti + "tuotelista.csv";
            const string tiedostopolkuTilaus = tallennusSijainti + "tilaus.csv";

            List<Tuote> tuotelista = csv.LueTuotteetTiedostosta(tiedostopolkuTuotelista);

            tulostaja.TulostaTuoterivinOtsikot();
            tulostaja.TulostaTuoterivit(tuotelista);

            Tilaus tilaus = new Tilaus();
            int valittuTunniste = 0;
            do
            {
                tulostaja.TulostaTuotteenValintaOhje();
                valittuTunniste = lukija.PyydaNumero();

                if(valittuTunniste != 0) {
                    Tuote valittuTuote = tuotelista[valittuTunniste - 1];
                    tilaus.LisaaTuote(valittuTuote);
                }

            } while (valittuTunniste > 0);


            tulostaja.TulostaTilaus(tilaus);
            csv.KirjoitaTiedostoon(tiedostopolkuTilaus, tilaus);
            // Varsinaisen ohjelman suoritus loppuu.
        }

    }
}
