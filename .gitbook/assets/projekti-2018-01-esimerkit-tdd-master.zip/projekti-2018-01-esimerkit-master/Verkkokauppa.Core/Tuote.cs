﻿using System;

namespace Verkkokauppa.Core
{
    public class Tuote
    {
        public string Tuotenimi { get; set; }
        public int Tuotenumero { get; set; }
        public double Hinta { get; set; }
        public double Alv { get; set; }

        public Tuote()
        {
        }
    }
}
