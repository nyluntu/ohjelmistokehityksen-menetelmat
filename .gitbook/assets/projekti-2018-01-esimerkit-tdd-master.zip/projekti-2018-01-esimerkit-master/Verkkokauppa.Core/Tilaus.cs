﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Verkkokauppa.Core
{
    public class Tilaus
    {
        public List<Tuote> Tuotteet { get; set; }

        public Tilaus()
        {
            this.Tuotteet = new List<Tuote>();
        }

        public void LisaaTuote(Tuote tuote)
        {
            if(tuote != null) {
                this.Tuotteet.Add(tuote);
            }
        }

        public double LaskeKokonaishinta()
        {
            return this.Tuotteet.Sum(tuote => tuote.Hinta);
        }
    }
}
